window.onload = function () {

    // Inject Blockly
    window.workspace = Blockly.inject('blocklyDiv', {
        toolbox: document.getElementById('toolbox')
    });

    // WebSocket for B4J
    window.b4j_ws = new WebSocket("ws://127.0.0.1:18888/hk32");

    b4j_ws.onopen  = () => console.log("WebSocket connected");
    b4j_ws.onclose = () => console.log("WebSocket closed");
    b4j_ws.onerror = e => console.log("WebSocket error", e);

    window.sendCodeToB4J = function(code) {
		alert(code);
    };

	function generateCommandsJSON(workspace) {
		const commands = [];

		function traverse(block) {
			if (!block) return;

			const generator = Blockly.JavaScript[block.type];
			if (generator) {
				try {
					const cmdObj = generator(block); // **already an object**
					commands.push(cmdObj);
				} catch(e) {
					console.error("Invalid JSON from block:", generator(block), e);
				}
			}

			traverse(block.getNextBlock());
		}

		workspace.getTopBlocks(true).forEach(block => traverse(block));

		return JSON.stringify(commands); // stringify **once here**
	}

	document.getElementById('btnGenerate').onclick = function() {
		const jsonStr = generateCommandsJSON(window.workspace);
		alert(jsonStr);  // send to B4J via alert
	};

	// Save Workspace Button
    document.getElementById('btnSaveWorkspace').onclick = function() {
        const xml = Blockly.Xml.workspaceToDom(workspace);
        const xmlText = Blockly.Xml.domToText(xml);
        alert(xmlText);
        // alert('[btnSaveWorkspace] xml=' + xmlText);
        // Optionally, send xmlText to B4J to save to file
    };

    // Load Workspace Button
    document.getElementById('btnLoadWorkspace').onclick = function() {
        const xmlText = prompt("Paste workspace XML here:");
        if (!xmlText) return;
        try {
            const xml = Blockly.Xml.textToDom(xmlText);
            workspace.clear();
            Blockly.Xml.domToWorkspace(xml, workspace);
        } catch(e) {
            alert("[btnLoadWorkspace][E] Failed to load workspace XML:", e);
            console.error("[btnLoadWorkspace][E] Failed to load workspace XML:", e);
        }
    };

};
