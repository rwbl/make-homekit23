Blockly.defineBlocksWithJsonArray([
  {
    "type": "yellow_on",
    "message0": "yellow LED on",
    "previousStatement": null,
    "nextStatement": null,
    "colour": 60
  },
  {
    "type": "yellow_off",
    "message0": "yellow LED off",
    "previousStatement": null,
    "nextStatement": null,
    "colour": 60
  },
  {
    "type": "open_door",
    "message0": "Open Door",
    "previousStatement": null,
    "nextStatement": null,
    "colour": 160
  },
  {
    "type": "delay",
    "message0": "wait %1 ms",
    "args0": [
      { "type": "field_number", "name": "DELAY", "value": 1000, "min": 0 }
    ],
    "previousStatement": null,
    "nextStatement": null,
    "colour": 120
  }
]);

// --- Generators returning JSON strings ---
Blockly.JavaScript['open_door'] = function(block) {
    return { command: "open_door" };
};

Blockly.JavaScript['yellow_on'] = function(block) {
    return { command: "yellow_on" };
};

Blockly.JavaScript['yellow_off'] = function(block) {
    return { command: "yellow_off" };
};

Blockly.JavaScript['delay'] = function(block) {
    var ms = block.getFieldValue("DELAY");
    return { command: "delay", value: parseInt(ms) };
};

Blockly.JavaScript['controls_repeat_ext'] = (block) => {
    const times = block.getFieldValue('NUM') || 1; // repeat count
    const innerBlocks = [];
    
    let current = block.getInputTargetBlock('DO'); // first block inside the loop
    while (current) {
        const gen = Blockly.JavaScript[current.type];
        if (gen) innerBlocks.push(gen(current)); // push the object directly
        current = current.getNextBlock();
    }
    
    return { command: "repeat", times: parseInt(times), blocks: innerBlocks }; // return object
};
