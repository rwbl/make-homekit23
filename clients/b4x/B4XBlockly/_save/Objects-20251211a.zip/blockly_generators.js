/*
    Project:    HomeKit32
    File:       blockly_generators.js
    Brief:      Handle Blockly block actions.
                Actions, in form of commands (JSON string) are sent to B4J using sendCommandToB4JAsync().
                This file provides both:
                  1) Runtime execution via async functions
                  2) Blockly code generation for blockToCode
                All async operations (like LED control, delay) are wrapped in runBlockQueue for safe execution.
*/

// ======================================================================
// GENERATORS
// ======================================================================

// ======================================================================
// --- Custom block generators (LEDs, connect/disconnect, delay) ---
// ======================================================================

// Connect to device
Blockly.JavaScript['connect'] = block => async () => {
    await sendCommandToB4JAsync({ command: "connect" });
};

// Disconnect
Blockly.JavaScript['disconnect'] = block => async () => {
    await sendCommandToB4JAsync({ command: "disconnect" });
};

// Turn yellow LED on/off
Blockly.JavaScript['yellow_led_on'] = block => async () => {
    await sendCommandToB4JAsync({ command: "yellow_led_on" });
};
Blockly.JavaScript['yellow_led_off'] = block => async () => {
    await sendCommandToB4JAsync({ command: "yellow_led_off" });
};

// Yellow LED with dynamic state (ON/OFF)
Blockly.JavaScript['yellow_led'] = block => async () => {
    const state = block.getFieldValue("STATE"); // "ON" or "OFF"
    await sendCommandToB4JAsync({ command: state === "ON" ? "yellow_led_on" : "yellow_led_off" });

    // Optional: dynamically change block color for visual feedback
    block.setColour(state === "ON" ? 90 : 60); // Green if ON, yellow if OFF
};

// Delay block
Blockly.JavaScript['delay'] = block => async () => {
    const ms = parseInt(block.getFieldValue("DELAY") || 1000);
    await sendCommandToB4JAsync({ command: "delay", value: ms });
    await new Promise(resolve => setTimeout(resolve, ms));
};

// ======================================================================
// --- Standard blocks ---
// ======================================================================

// Comment block: generates nothing
Blockly.JavaScript['comment_block'] = block => '';

// Log block: outputs the connected input or empty
Blockly.JavaScript['log_block'] = block => {
    const valueCode = Blockly.JavaScript.valueToCode(block, 'TEXT', Blockly.JavaScript.ORDER_ATOMIC) || '""';
    return `runBlockQueue([async () => { await sendCommandToB4JAsync({ command: "log", value: ${valueCode} }); }]);\n`;
};

// Text literal
// Text literal (returns tuple [code, order])
Blockly.JavaScript['text_literal'] = block => {
    const text = block.getFieldValue('TEXT') || '';
    return [`"${text}"`, Blockly.JavaScript.ORDER_ATOMIC];
};

// ======================================================================
// --- Logic blocks ---
// ======================================================================

// Simple IF
Blockly.JavaScript['logic_if'] = block => {
    const cond = Blockly.JavaScript.valueToCode(block, 'COND', Blockly.JavaScript.ORDER_NONE) || 'false';
    const branch = Blockly.JavaScript.statementToCode(block, 'DO');
    return `runBlockQueue([async () => { if (${cond}) {\n${branch}} }]);\n`;
};

// IF ELSE
Blockly.JavaScript['logic_if_else'] = block => {
    const cond = Blockly.JavaScript.valueToCode(block, 'COND', Blockly.JavaScript.ORDER_NONE) || 'false';
    const branchIf = Blockly.JavaScript.statementToCode(block, 'DO');
    const branchElse = Blockly.JavaScript.statementToCode(block, 'ELSE');
    return `runBlockQueue([async () => { if (${cond}) {\n${branchIf}} else {\n${branchElse}} }]);\n`;
};

// ELSE IF
Blockly.JavaScript['logic_else_if'] = block => {
    const cond = Blockly.JavaScript.valueToCode(block, 'COND', Blockly.JavaScript.ORDER_NONE) || 'false';
    const branch = Blockly.JavaScript.statementToCode(block, 'DO');
    return `runBlockQueue([async () => { if (${cond}) {\n${branch}} }]);\n`;
};

// ======================================================================
// --- Comparison blocks ---
// ======================================================================

// Generic function to handle comparisons
function generateLogicCompare(block) {
    const opMap = {
        'EQ': '==',
        'NEQ': '!=',
        'LT': '<',
        'LTE': '<=',
        'GT': '>',
        'GTE': '>='
    };

    const A = Blockly.JavaScript.valueToCode(block, 'A', Blockly.JavaScript.ORDER_NONE) || '0';
    const B = Blockly.JavaScript.valueToCode(block, 'B', Blockly.JavaScript.ORDER_NONE) || '0';
    const op = opMap[block.getFieldValue('OP')] || '==';
    return [ `${A} ${op} ${B}`, Blockly.JavaScript.ORDER_ATOMIC ];
}

// Assign this generator to all relevant comparison block types
Blockly.JavaScript['logic_compare'] = generateLogicCompare;
Blockly.JavaScript['logic_compare_eq'] = generateLogicCompare;
Blockly.JavaScript['logic_compare_neq'] = generateLogicCompare;
Blockly.JavaScript['logic_compare_lt'] = generateLogicCompare;
Blockly.JavaScript['logic_compare_lte'] = generateLogicCompare;
Blockly.JavaScript['logic_compare_gt'] = generateLogicCompare;
Blockly.JavaScript['logic_compare_gte'] = generateLogicCompare;

// ======================================================================
// --- Loops ---
// ======================================================================

// Repeat N times
Blockly.JavaScript['repeat_loop'] = block => {
    const timesCode = Blockly.JavaScript.valueToCode(block, 'TIMES', Blockly.JavaScript.ORDER_NONE) || '1';
    const branch = Blockly.JavaScript.statementToCode(block, 'DO');
    return `runBlockQueue([async () => { for(let i=0;i<${timesCode};i++) {\n${branch}} }]);\n`;
};

// While loop
Blockly.JavaScript['while_loop'] = block => {
    const cond = Blockly.JavaScript.valueToCode(block, 'COND', Blockly.JavaScript.ORDER_NONE) || 'false';
    const branch = Blockly.JavaScript.statementToCode(block, 'DO');
    return `runBlockQueue([async () => { let iter=0; const MAX_ITER=1000; while(${cond} && iter<MAX_ITER){ iter++;\n${branch}} }]);\n`;
};

// ======================================================================
// --- Variables ---
// ======================================================================

// Set variable
Blockly.JavaScript['variables_set'] = block => {
    const varName = block.getFieldValue("VAR");
    const valueCode = Blockly.JavaScript.valueToCode(block, 'VALUE', Blockly.JavaScript.ORDER_NONE) || 'null';
    return `runBlockQueue([async () => { workspaceVars["${varName}"] = ${valueCode}; }]);\n`;
};

// Get variable
Blockly.JavaScript['variables_get'] = block => {
    const varName = block.getFieldValue("VAR");
    return [`workspaceVars["${varName}"]`, Blockly.JavaScript.ORDER_ATOMIC];
};

// ======================================================================
// --- Start / Stop blocks ---
// ======================================================================

// Start block executes connected blocks
Blockly.JavaScript['start_block'] = block => {
    const branch = Blockly.JavaScript.statementToCode(block, 'DO');
    return `runBlockQueue([async () => { await sendCommandToB4JAsync({ command: "start" });\n${branch} }]);\n`;
};

// Stop block
Blockly.JavaScript['stop_block'] = block => 
    `runBlockQueue([async () => { await sendCommandToB4JAsync({ command: "stop" }); }]);\n`;

// ======================================================================
// --- Override Blockly.prompt for variable creation ---
// ======================================================================

// Show variable dialog and return Promise
function showVariableDialog(defaultName = "") {
    return new Promise(resolve => {
        const dialog = document.getElementById('variableDialog');
        const input = document.getElementById('varNameInput');
        const btnOK = document.getElementById('btnVarOK');
        const btnCancel = document.getElementById('btnVarCancel');

        input.value = defaultName;
        dialog.style.display = 'block';
        input.focus();

        function cleanup() {
            dialog.style.display = 'none';
            btnOK.removeEventListener('click', okHandler);
            btnCancel.removeEventListener('click', cancelHandler);
        }

        function okHandler() { cleanup(); resolve(input.value.trim()); }
        function cancelHandler() { cleanup(); resolve(null); }

        btnOK.addEventListener('click', okHandler);
        btnCancel.addEventListener('click', cancelHandler);
    });
}

// Override Blockly.prompt
Blockly.prompt = async function(message, defaultValue, callback) {
    const name = await showVariableDialog(defaultValue);
    callback(name);
};
